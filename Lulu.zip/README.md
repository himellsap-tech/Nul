# HIMEL AI Companion (Fabric 1.21.1 prototype)

**Current build:** GUI/keybind + client controller scaffold only. It is NOT yet a full Gemini agent, voice system, companion NPC, or autonomous gameplay implementation.

## Build
- Install JDK 21 and Gradle (or use the included Gradle wrapper if you add one).
- From this folder run `gradle build`.
- Output: `build/libs/himel-ai-companion-0.1.0.jar`
- Install Fabric Loader 0.16+ for Minecraft 1.21.1 and Fabric API 0.100.0+.

## Use
- Press **Right Shift** to open the companion GUI.
- Follow/Autopilot are placeholders; STOP clears local key presses.
- Sodium compatibility: this is a client GUI mod and does not replace rendering; it should coexist with Sodium.

## Security
Do not put a Gemini API key in the mod/JAR or commit it. The key pasted in chat should be revoked and replaced. The next version should call a private backend (or a local config key with explicit warning) and implement Gemini tool/function calling with a strict allowlist.

## Roadmap
1. Gemini backend + conversation history.
2. Minecraft context snapshot and game-command allowlist.
3. Real autonomous navigation/actions with safety limits and stop key.
4. Companion entity (server-side mod required for multiplayer visibility).
5. TTS + microphone speech recognition.
6. Multiplayer compatibility testing against server permissions/anti-cheat.


## Cloud build (phone-friendly)
This repository includes `.github/workflows/build.yml`. Upload/push this project to a GitHub repository, then open **Actions → Build HIMEL AI Companion → Run workflow**. After the green run, open its run page and download the `himel-ai-companion-jar` artifact. The artifact is a ZIP containing the compiled `.jar`.
