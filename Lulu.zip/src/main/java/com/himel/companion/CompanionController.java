package com.himel.companion;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.MathHelper;

/**
 * Client-side prototype controller. It only sends normal local player inputs;
 * it does not bypass server permissions, anticheat, or movement validation.
 */
public final class CompanionController {
    private boolean follow = false, autopilot = false;
    private String status = "Idle";
    private int ticks;

    public boolean follow() { return follow; }
    public boolean autopilot() { return autopilot; }
    public String status() { return status; }
    public void setFollow(boolean v) { follow = v; status = v ? "Follow enabled" : "Follow disabled"; }
    public void setAutopilot(boolean v) { autopilot = v; status = v ? "Autopilot ON (basic)" : "Autopilot OFF"; }

    public void tick(MinecraftClient mc) {
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null) return;
        ticks++;
        // Very conservative demo autopilot: stop sprinting and avoid holding keys.
        // Full navigation/AI task execution is intentionally not claimed here.
        if (autopilot && ticks % 20 == 0) {
            status = "Autopilot active — awaiting a task";
        }
    }

    public void stop(MinecraftClient mc) {
        autopilot = false; follow = false;
        if (mc.options != null) {
            mc.options.forwardKey.setPressed(false); mc.options.backKey.setPressed(false);
            mc.options.leftKey.setPressed(false); mc.options.rightKey.setPressed(false);
            mc.options.jumpKey.setPressed(false); mc.options.sprintKey.setPressed(false);
            mc.options.attackKey.setPressed(false); mc.options.useKey.setPressed(false);
        }
        status = "Stopped";
    }
}
