package com.himel.companion;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import net.minecraft.client.MinecraftClient;

public final class CompanionScreen extends Screen {
    private TextFieldWidget input;
    private String answer = "HIMEL companion ready. Gemini connection is not configured.";
    private int panelX, panelY;

    public CompanionScreen() { super(Text.literal("HIMEL AI Companion")); }

    @Override protected void init() {
        panelX = (width - 320) / 2; panelY = (height - 210) / 2;
        input = new TextFieldWidget(textRenderer, panelX + 16, panelY + 154, 288, 20, Text.literal("Ask companion"));
        input.setMaxLength(240); addDrawableChild(input);
        addDrawableChild(ButtonWidget.builder(Text.literal("Send"), b -> send())
            .dimensions(panelX + 16, panelY + 180, 70, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Follow: " + (HimelCompanionClient.CONTROLLER.follow() ? "ON" : "OFF")),
            b -> { var c = HimelCompanionClient.CONTROLLER; c.setFollow(!c.follow()); clearAndInit(); })
            .dimensions(panelX + 92, panelY + 180, 90, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Autopilot"),
            b -> { var c = HimelCompanionClient.CONTROLLER; c.setAutopilot(!c.autopilot()); clearAndInit(); })
            .dimensions(panelX + 188, panelY + 180, 78, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("STOP"), b -> HimelCompanionClient.CONTROLLER.stop(client))
            .dimensions(panelX + 270, panelY + 180, 34, 20).build());
        setInitialFocus(input);
    }

    private void send() {
        String q = input.getText().trim();
        if (!q.isEmpty()) {
            answer = "You: " + q + "\nAI: Gemini backend not wired yet. Add a private proxy/API config to enable responses.";
            input.setText("");
        }
    }

    @Override public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx, mouseX, mouseY, delta);
        ctx.fill(panelX, panelY, panelX + 320, panelY + 210, 0xEE101827);
        ctx.drawBorder(panelX, panelY, 320, 210, 0xFF62C8FF);
        ctx.drawText(textRenderer, "HIMEL AI COMPANION", panelX + 16, panelY + 12, 0xFF74D7FF, false);
        ctx.drawText(textRenderer, "Mode: " + HimelCompanionClient.CONTROLLER.status(), panelX + 16, panelY + 30, 0xFFE0EAF5, false);
        String[] lines = answer.split("\\n");
        int y = panelY + 54;
        for (String line : lines) {
            ctx.drawText(textRenderer, line.length() > 46 ? line.substring(0, 46) : line, panelX + 16, y, 0xFFFFFFFF, false);
            y += 12; if (y > panelY + 140) break;
        }
        super.render(ctx, mouseX, mouseY, delta);
    }
    @Override public boolean shouldPause() { return false; }
}
